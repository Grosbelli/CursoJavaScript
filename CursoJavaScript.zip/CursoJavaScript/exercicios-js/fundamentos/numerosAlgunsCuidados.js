console.log(7 / 0)
console.log("10" / 2)    //em fava script da certo.
console.log("Show" * 2)   //NaN = Not a Number
console.log(0.1 + 0.7)
// console.log(10.toString())
console.log((10.345).toFixed(2))   // isso dá certo, sem precisar armazenar numa variável.
console.log('3' + 2) //Ele vai concatenar, porque aqui a string tem a preferência. Qualquer outra sinal ele faz a conta.
console.log('3' - 2)