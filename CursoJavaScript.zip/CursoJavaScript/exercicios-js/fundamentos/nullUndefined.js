let valor //não inicializada
console.log(valor) //valor undefined, não foi atribuido, não foi iniciada, mas foi declarada. 

valor = null //ela não tem valor, e também não tem nem endereço de memória. Ausência de valor. 
console.log(valor)
/*console.log(valor.toString())*/      //vai da erro. 

const produto = {}
console.log(produto.preco)
console.log(produto)

produto.preco = 3.50
console.log(produto)

produto.preco = undefined //evite atribuir undefined. 
console.log(!!produto.preco)
//delete produto.preco  //caso queira tirar um atributo do objeto.
console.log(produto)

produto.preco = null //sem preço 
console.log(!!produto.preco)
console.log(produto)
