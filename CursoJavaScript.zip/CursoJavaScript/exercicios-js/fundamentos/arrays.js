const valores = [7.7, 8.9, 6.3, 9.2] //Arrays separados por vírgulas
console.log(valores[0], valores [3])
console.log(valores[4]) //esse indice não existe, ele simplesmente retorna "undefined", não gerando erro. 

valores[4] = 10 //dei valor ao indice 4
console.log(valores)
console.log(valores.length)

valores.push({id: 3}, false, null, 'teste') //adicionar vários valores além do que já tem
console.log(valores)

console.log(valores.pop()) 
delete valores[0] //ele vai tirar o ultimo valor do array. No caso ele exclui o valor. Depende do "POP"
console.log(valores)

console.log(typeof valores) //Array é do tipo object



valores[10] = 5 //ele especifica que tem indices vazios nesse array, e joga esse valor no indice 10. 

