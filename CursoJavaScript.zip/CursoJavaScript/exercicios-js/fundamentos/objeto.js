const prod1 = {}  //criei objeto
prod1.nome = 'Celular Ultra Mega'  //Ele cria dinamicamente esse valor no objeto. Já passa o identificador e o valor do identificador. 
prod1.preco = 4998.90 //Criei dinamicamente o valor e o identificador.

prod1['Desconto Legal'] = 0.40 // evitar atributos com espaço. Ele coloca o valor no objeto sem identificador também. 

console.log(prod1)

//da pra ter objetos dentro de um objeto.
const prod2 = {
    nome: 'Camisa Polo',
    preco: 79.90,
    obj: {
        blabla: 1,
        obj:{
            blabla:2
        }
    }
}


'{ "nome": "Camisa Polo", "preco": 79.90}'   //Isso é um JSON. Ele não é a mesma coisa que um objeto, não confunda.

console.log(prod2)