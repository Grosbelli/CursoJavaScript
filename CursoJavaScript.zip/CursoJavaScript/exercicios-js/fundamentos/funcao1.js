// Funcao sem retorno 
function imprimirSoma(a, b){
    console.log(a + b)
}

imprimirSoma(2, 3)
imprimirSoma(2) //Vai somar o número 2 com um valor undefined, vai dar o resultado NaN (nota a number)
imprimirSoma(2, 3, 4, 5, 6, 7) //Vai dar certo, vai somar os 2 primeiros números que é passado por parâmetro, e o restante ele vai ignorar. 
imprimirSoma()

//Funcao com retorno
function soma(a, b = 0){
    return a + b
}

console.log(soma(2, 3))
console.log(soma(2)) //aqui da certo, porque ele considerou o valor que já foi definido na function para o identificador "b" 

