console.log(typeof Object) //qual o tipo de dado que está por trás do objeto. É uma função.

class Produto {}
console.log(typeof Produto) //Classe também é uma função.