let isAtivo = false
console.log(isAtivo)

isAtivo = true
console.log(isAtivo)

isAtivo = 1
console.log(!!isAtivo)  // "!" = Negação, duas vezes é "neutro". Se eu não usar essa exclamação, ele vai imprimir o valor "1" apenas.

console.log('os verdadeiros...')
console.log(!!3)
console.log(!!-1)
console.log(!!' ')
console.log(!!'texto')
console.log(!![]) //array
console.log(!!{}) //objeto
console.log(!!Infinity)
console.log(!!(isAtivo = true))


console.log('os falsos...')
console.log(!!0)
console.log(!!'') //string vazia.
console.log(!!null)
console.log(!!NaN) //not a number
console.log(!!undefined)
console.log(!!(isAtivo = false))


console.log('pra finalizar...')
console.log(!!('' || null || 0 || ' ')) //Operção lógica "OU". Uma sendo verdadeiro, será verdadeiro

let nome = ''
console.log(nome || 'Desconhecido')  //caso o a variável der falso, ele irá imprimir o que está do outro lado do "ou". Caso seja vedadeiro, ele imprimi a variável nome
