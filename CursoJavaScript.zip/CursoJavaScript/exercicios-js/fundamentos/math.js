const raio = 5.6
const area = Math.PI * Math.pow(raio, 2)  // "Math.pow" eleva ao quadrado

console.log(area)
console.log(typeof Math)
